#ifndef __USART1_H
#define	__USART1_H

#include "stm32f4xx.h"
#include <stdio.h>

/* ��ͬ�Ĵ��ڹ��ص����߲�һ����ʱ��ʹ�ܺ���Ҳ��һ������ֲʱҪע�� 
 * ����1��6��      RCC_APB2PeriphClockCmd
 * ����2/3/4/5/7�� RCC_APB1PeriphClockCmd
 */

//���Ŷ���
#define             macUSART_BAUD_RATE                       115200//9600

#define             macUSARTx                                 USART1
#define             macUSART_APBxClock_FUN                    RCC_APB2PeriphClockCmd
#define             macUSART_CLK                              RCC_APB2Periph_USART1


#define             macUSART_TX_GPIO_CLK                     RCC_AHB1Periph_GPIOA    
#define             macUSART_TX_PORT                         GPIOA   
#define             macUSART_TX_PIN                          GPIO_Pin_9
#define             macUSART_TX_AF                           GPIO_AF_USART1
#define             macUSART_TX_SOURCE                       GPIO_PinSource9

#define             macUSART_RX_GPIO_CLK                     RCC_AHB1Periph_GPIOA    
#define             macUSART_RX_PORT                         GPIOA   
#define             macUSART_RX_PIN                          GPIO_Pin_10
#define             macUSART_RX_AF                           GPIO_AF_USART1
#define             macUSART_RX_SOURCE                       GPIO_PinSource10


#define             macUSART_IRQ                             USART1_IRQn


void USART1_NVIC_Config(void);
void USART1_Config(void);
void USART_GetCmd(char *chpt);
void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);
void Usart_SendString( USART_TypeDef * pUSARTx, char *str);
	

#endif /* __USART1_H */
