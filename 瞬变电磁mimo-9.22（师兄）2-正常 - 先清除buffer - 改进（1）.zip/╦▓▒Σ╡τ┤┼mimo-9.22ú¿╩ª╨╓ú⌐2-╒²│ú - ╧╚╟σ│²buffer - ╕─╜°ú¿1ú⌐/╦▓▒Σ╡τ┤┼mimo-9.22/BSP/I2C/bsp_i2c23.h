#ifndef __I2C23_H
#define	__I2C23_H

#include "stm32f4xx.h"


/* STM32 I2C ����ģʽ */
#define I2C23_Speed              400000    //����ģʽ400Kbit/s

/* �����ַֻҪ��STM32��ҵ�I2C������ַ��һ������ */
#define I2C2_OWN_ADDRESS7      0X0B   
#define I2C3_OWN_ADDRESS7      0X0C

/*I2C2�ӿ�*/
#define CONTROL1_I2C                          I2C2
#define CONTROL1_I2C_CLK                      RCC_APB1Periph_I2C2
#define CONTROL1_I2C_CLK_INIT							  	RCC_APB1PeriphClockCmd

#define CONTROL1_I2C_SCL_PIN                  GPIO_Pin_4                 
#define CONTROL1_I2C_SCL_GPIO_PORT            GPIOH                       
#define CONTROL1_I2C_SCL_GPIO_CLK             RCC_AHB1Periph_GPIOH
#define CONTROL1_I2C_SCL_SOURCE               GPIO_PinSource4
#define CONTROL1_I2C_SCL_AF                   GPIO_AF_I2C2

#define CONTROL1_I2C_SDA_PIN                  GPIO_Pin_5                  
#define CONTROL1_I2C_SDA_GPIO_PORT            GPIOH                       
#define CONTROL1_I2C_SDA_GPIO_CLK             RCC_AHB1Periph_GPIOH
#define CONTROL1_I2C_SDA_SOURCE               GPIO_PinSource5
#define CONTROL1_I2C_SDA_AF                   GPIO_AF_I2C2

/*I2C3�ӿ�*/
#define CONTROL2_I2C                          I2C3
#define CONTROL2_I2C_CLK                      RCC_APB1Periph_I2C3
#define CONTROL2_I2C_CLK_INIT							  	RCC_APB1PeriphClockCmd

#define CONTROL2_I2C_SCL_PIN                  GPIO_Pin_8                 
#define CONTROL2_I2C_SCL_GPIO_PORT            GPIOA                       
#define CONTROL2_I2C_SCL_GPIO_CLK             RCC_AHB1Periph_GPIOA
#define CONTROL2_I2C_SCL_SOURCE               GPIO_PinSource8
#define CONTROL2_I2C_SCL_AF                   GPIO_AF_I2C3

#define CONTROL2_I2C_SDA_PIN                  GPIO_Pin_8                  
#define CONTROL2_I2C_SDA_GPIO_PORT            GPIOH                       
#define CONTROL2_I2C_SDA_GPIO_CLK             RCC_AHB1Periph_GPIOH
#define CONTROL2_I2C_SDA_SOURCE               GPIO_PinSource8
#define CONTROL2_I2C_SDA_AF                   GPIO_AF_I2C3


/*�ȴ���ʱʱ��*/
#define I2CT_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define I2CT_LONG_TIMEOUT         ((uint32_t)(10 * I2CT_FLAG_TIMEOUT))

/*��Ϣ���*/
#define EEPROM_DEBUG_ON         0

#define EEPROM_INFO(fmt,arg...)           printf("<<-EEPROM-INFO->> "fmt"\n",##arg)
#define EEPROM_ERROR(fmt,arg...)          printf("<<-EEPROM-ERROR->> "fmt"\n",##arg)
#define EEPROM_DEBUG(fmt,arg...)          do{\
                                          if(EEPROM_DEBUG_ON)\
                                          printf("<<-EEPROM-DEBUG->> [%d]"fmt"\n",__LINE__, ##arg);\
                                          }while(0)

/* 
 * MCP_Address
 * 0 1 0 0 A2 A1 A0 R/W                    R/W=0=write;R/W=1=read
 * 0 1 0 0 0  0  0  0   = 0X40    д��ַ 
 * 0 1 0 0 0  0  0  1   = 0X41    ����ַ
 * 0 1 0 0 0  0  1  0   = 0X42
 * 0 1 0 0 0  1  0  0   = 0X44
 * 0 1 0 0 0  1  1  0   = 0X46
 * 0 1 0 0 1  0  0  0   = 0X48
 * 0 1 0 0 1  0  1  0   = 0X4A
 * 0 1 0 0 1  1  0  0   = 0X4C
 * 0 1 0 0 1  1  1  0   = 0X4E																																																											
 */

/* MCP_Register_Addresses defines */
#define IODIRA_REGISTER_ADDRESS  0x00 
#define IODIRB_REGISTER_ADDRESS  0x01
																					
#define IOCONA_REGISTER_ADDRESS  0x0A 
#define IOCONB_REGISTER_ADDRESS  0x0B

#define GPIOA_REGISTER_ADDRESS   0x12 
#define GPIOB_REGISTER_ADDRESS   0x13																					
											


void CONTROL_I2C_Init(void);
 
uint32_t I2C2_CENDCOM(I2C_TypeDef* I2Cx,u8 MCP_Address,u8 pBuffer);
uint8_t WriteMCPreg8(I2C_TypeDef* I2Cx,u8 Address,u8 MCP_address,u8 RegValue);
void ControlPinOutA(I2C_TypeDef* I2Cx,u8 MCP_address,u8 GPAregValue);
void ControlPinOutB(I2C_TypeDef* I2Cx,u8 MCP_address,u8 GPBregValue);
void I2CSendCtlCmd(I2C_TypeDef* I2Cx,u8 address,u16 buf);
void Delay(__IO uint32_t nCount);
uint8_t MCP_Byte_Read_5(I2C_TypeDef* I2Cx,u8 MCP_Address,uint8_t addr);


#endif /* __I2C23_H */

