#ifndef _SOFT_I2C23_H
#define _SOFT_I2C23_H

#include "stm32f4xx.h"
#include <inttypes.h>


#define EEPROM_I2C_WR	0		/* д����bit */
#define EEPROM_I2C_RD	1		/* ������bit */


/* ����I2C�������ӵ�GPIO�˿�, �û�ֻ��Ҫ�޸�����4�д��뼴������ı�SCL��SDA������ */
/*I2C2�ӿ�*/


#define SCONTROL1_I2C_SCL_PIN                  GPIO_Pin_5                
#define SCONTROL1_I2C_SCL_GPIO_PORT            GPIOD                      
#define SCONTROL1_I2C_SCL_GPIO_CLK             RCC_AHB1Periph_GPIOD

#define SCONTROL1_I2C_SDA_PIN                  GPIO_Pin_3                  
#define SCONTROL1_I2C_SDA_GPIO_PORT            GPIOD                      
#define SCONTROL1_I2C_SDA_GPIO_CLK             RCC_AHB1Periph_GPIOD

/*I2C3�ӿ�*/


#define SCONTROL2_I2C_SCL_PIN                  GPIO_Pin_6                
#define SCONTROL2_I2C_SCL_GPIO_PORT            GPIOD                    
#define SCONTROL2_I2C_SCL_GPIO_CLK             RCC_AHB1Periph_GPIOD

#define SCONTROL2_I2C_SDA_PIN                  GPIO_Pin_4                 
#define SCONTROL2_I2C_SDA_GPIO_PORT            GPIOD                     
#define SCONTROL2_I2C_SDA_GPIO_CLK             RCC_AHB1Periph_GPIOD



/* �����дSCL��SDA�ĺ꣬�����Ӵ���Ŀ���ֲ�ԺͿ��Ķ��� */
#if 1	/* �������룺 1 ѡ��GPIO�Ŀ⺯��ʵ��IO��д */
	#define CONTROL1_I2C_SCL_1()       GPIO_SetBits(SCONTROL1_I2C_SCL_GPIO_PORT, SCONTROL1_I2C_SCL_PIN)		/* SCL = 1 */
	#define CONTROL1_I2C_SCL_0()       GPIO_ResetBits(SCONTROL1_I2C_SCL_GPIO_PORT, SCONTROL1_I2C_SCL_PIN)		/* SCL = 0 */
	
	#define CONTROL1_I2C_SDA_1()       GPIO_SetBits(SCONTROL1_I2C_SDA_GPIO_PORT, SCONTROL1_I2C_SDA_PIN)		/* SDA = 1 */
	#define CONTROL1_I2C_SDA_0()       GPIO_ResetBits(SCONTROL1_I2C_SDA_GPIO_PORT, SCONTROL1_I2C_SDA_PIN)		/* SDA = 0 */
	
	#define CONTROL1_I2C_SDA_READ()    GPIO_ReadInputDataBit(SCONTROL1_I2C_SDA_GPIO_PORT, SCONTROL1_I2C_SDA_PIN)	/* ��SDA����״̬ */
  
  #define CONTROL2_I2C_SCL_1()       GPIO_SetBits(SCONTROL2_I2C_SCL_GPIO_PORT, SCONTROL2_I2C_SCL_PIN)		/* SCL = 1 */
	#define CONTROL2_I2C_SCL_0()       GPIO_ResetBits(SCONTROL2_I2C_SCL_GPIO_PORT, SCONTROL2_I2C_SCL_PIN)		/* SCL = 0 */
	
	#define CONTROL2_I2C_SDA_1()       GPIO_SetBits(SCONTROL2_I2C_SDA_GPIO_PORT, SCONTROL2_I2C_SDA_PIN)		/* SDA = 1 */
	#define CONTROL2_I2C_SDA_0()       GPIO_ResetBits(SCONTROL2_I2C_SDA_GPIO_PORT, SCONTROL2_I2C_SDA_PIN)		/* SDA = 0 */
	
	#define CONTROL2_I2C_SDA_READ()    GPIO_ReadInputDataBit(SCONTROL2_I2C_SDA_GPIO_PORT, SCONTROL2_I2C_SDA_PIN)	/* ��SDA����״̬ */
  
  
//  #define EEPROM_I2C_SCL_1()  GPIO_SetBits(EEPROM_I2C_GPIO_PORT, EEPROM_I2C_SCL_PIN)		/* SCL = 1 */
//	#define EEPROM_I2C_SCL_0()  GPIO_ResetBits(EEPROM_I2C_GPIO_PORT, EEPROM_I2C_SCL_PIN)		/* SCL = 0 */
//	
//	#define EEPROM_I2C_SDA_1()  GPIO_SetBits(EEPROM_I2C_GPIO_PORT, EEPROM_I2C_SDA_PIN)		/* SDA = 1 */
//	#define EEPROM_I2C_SDA_0()  GPIO_ResetBits(EEPROM_I2C_GPIO_PORT, EEPROM_I2C_SDA_PIN)		/* SDA = 0 */
//	
//	#define EEPROM_I2C_SDA_READ()  GPIO_ReadInputDataBit(EEPROM_I2C_GPIO_PORT, EEPROM_I2C_SDA_PIN)	/* ��SDA����״̬ */
#else	/* �����֧ѡ��ֱ�ӼĴ�������ʵ��IO��д */
    /*��ע�⣺����д������IAR��߼����Ż�ʱ���ᱻ�����������Ż� */
	#define EEPROM_I2C_SCL_1()  EEPROM_I2C_GPIO_PORT->BSRRL = EEPROM_I2C_SCL_PIN				/* SCL = 1 */
	#define EEPROM_I2C_SCL_0()  EEPROM_I2C_GPIO_PORT->BSRRH = EEPROM_I2C_SCL_PIN				/* SCL = 0 */
	
	#define EEPROM_I2C_SDA_1()  EEPROM_I2C_GPIO_PORT->BSRRL = EEPROM_I2C_SDA_PIN				/* SDA = 1 */
	#define EEPROM_I2C_SDA_0()  EEPROM_I2C_GPIO_PORT->BSRRH = EEPROM_I2C_SDA_PIN				/* SDA = 0 */
	
	#define EEPROM_I2C_SDA_READ()  ((EEPROM_I2C_GPIO_PORT->IDR & EEPROM_I2C_SDA_PIN) != 0)	/* ��SDA����״̬ */
#endif


//void i2c_Start(void);
//void i2c_Stop(void);
//void i2c_SendByte(uint8_t _ucByte);
//uint8_t i2c_ReadByte(void);
//uint8_t i2c_WaitAck(void);
//void i2c_Ack(void);
//void i2c_NAck(void);
//uint8_t i2c_CheckDevice(uint8_t _Address);


/* 
 * MCP_Address
 * 0 1 0 0 A2 A1 A0 R/W                    R/W=0=write;R/W=1=read
 * 0 1 0 0 0  0  0  0   = 0X40    д��ַ 
 * 0 1 0 0 0  0  0  1   = 0X41    ����ַ
 * 0 1 0 0 0  0  1  0   = 0X42
 * 0 1 0 0 0  1  0  0   = 0X44
 * 0 1 0 0 0  1  1  0   = 0X46
 * 0 1 0 0 1  0  0  0   = 0X48
 * 0 1 0 0 1  0  1  0   = 0X4A
 * 0 1 0 0 1  1  0  0   = 0X4C
 * 0 1 0 0 1  1  1  0   = 0X4E																																																											
 */

/* MCP_Register_Addresses defines */
#define IODIRA_REGISTER_ADDRESS  0x00 
#define IODIRB_REGISTER_ADDRESS  0x01
																					
#define IOCONA_REGISTER_ADDRESS  0x0A 
#define IOCONB_REGISTER_ADDRESS  0x0B

#define GPIOA_REGISTER_ADDRESS   0x12 
#define GPIOB_REGISTER_ADDRESS   0x13				


void CONTROL1_I2C_Start(void);
void CONTROL2_I2C_Start(void);
void CONTROL1_I2C_Stop(void);
void CONTROL2_I2C_Stop(void);
void CONTROL1_I2C_SendByte(uint8_t _ucByte);
void CONTROL2_I2C_SendByte(uint8_t _ucByte);
uint8_t CONTROL1_I2C_ReadByte(void);
uint8_t CONTROL2_I2C_ReadByte(void);
uint8_t CONTROL1_I2C_WaitAck(void);
uint8_t CONTROL2_I2C_WaitAck(void);
void CONTROL1_I2C_Ack(void);
void CONTROL2_I2C_Ack(void);
void CONTROL1_I2C_NAck(void);
void CONTROL2_I2C_NAck(void);
uint8_t CONTROL1_WriteMCPreg8(u8 Address,u8 MCP_address,u8 RegValue);
uint8_t CONTROL2_WriteMCPreg8(u8 Address,u8 MCP_address,u8 RegValue);
void Control1_PinOutA(u8 MCP_regaddress,u8 GPAregValue);
void Control1_PinOutB(u8 MCP_regaddress,u8 GPBregValue);
void Control2_PinOutA(u8 MCP_regaddress,u8 GPAregValue);
void Control2_PinOutB(u8 MCP_regaddress,u8 GPBregValue);
void I2C1_SendCtlCmd(u8 MCP_Address,u16 buf);
void I2C2_SendCtlCmd(u8 MCP_Address,u16 buf);
void CONTROL_I2C_soft_Init(void);
void Delay_soft(__IO uint32_t nCount);
uint8_t MCP_Byte_Read_1(int Mcpchip,u8 MCP_address,uint8_t addr);




#endif

