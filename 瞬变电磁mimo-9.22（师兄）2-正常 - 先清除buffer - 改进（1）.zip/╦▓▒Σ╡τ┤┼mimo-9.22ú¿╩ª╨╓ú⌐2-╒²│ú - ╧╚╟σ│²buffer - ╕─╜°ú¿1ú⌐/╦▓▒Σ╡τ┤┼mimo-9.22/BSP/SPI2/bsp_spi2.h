#ifndef __SPI2_H
#define __SPI2_H

#include "stm32f4xx.h"
#include <stdio.h>


/* ***********************************************  */
#define SLAVE_SPI                           SPI4
#define SLAVE_SPI_CLK                       RCC_APB2Periph_SPI4
#define SLAVE_SPI_CLK_INIT                  RCC_APB2PeriphClockCmd

#define SLAVE_SPI_SCK_PIN                   GPIO_Pin_2                  
#define SLAVE_SPI_SCK_GPIO_PORT             GPIOE                       
#define SLAVE_SPI_SCK_GPIO_CLK              RCC_AHB1Periph_GPIOE
#define SLAVE_SPI_SCK_PINSOURCE             GPIO_PinSource2
#define SLAVE_SPI_SCK_AF                    GPIO_AF_SPI4

#define SLAVE_SPI_MISO_PIN                  GPIO_Pin_5                
#define SLAVE_SPI_MISO_GPIO_PORT            GPIOE                   
#define SLAVE_SPI_MISO_GPIO_CLK             RCC_AHB1Periph_GPIOE
#define SLAVE_SPI_MISO_PINSOURCE            GPIO_PinSource5
#define SLAVE_SPI_MISO_AF                   GPIO_AF_SPI4

#define SLAVE_SPI_MOSI_PIN                  GPIO_Pin_6                
#define SLAVE_SPI_MOSI_GPIO_PORT            GPIOE                    
#define SLAVE_SPI_MOSI_GPIO_CLK             RCC_AHB1Periph_GPIOE
#define SLAVE_SPI_MOSI_PINSOURCE            GPIO_PinSource6
#define SLAVE_SPI_MOSI_AF                   GPIO_AF_SPI4

#define SLAVE_SPI1_CS_PIN                   GPIO_Pin_4               
#define SLAVE_SPI1_CS_GPIO_PORT             GPIOE   
#define SLAVE_SPI1_CS_PINSOURCE             GPIO_PinSource4
#define SLAVE_SPI1_CS_GPIO_CLK              RCC_AHB1Periph_GPIOE
#define SLAVE_SPI1_CS_AF                    GPIO_AF_SPI4





#define SLAVE_SPI1_CS_LOW()      {SLAVE_SPI1_CS_GPIO_PORT->BSRRH=SLAVE_SPI1_CS_PIN;}
#define SLAVE_SPI1_CS_HIGH()     {SLAVE_SPI1_CS_GPIO_PORT->BSRRL=SLAVE_SPI1_CS_PIN;}
/*SPI�ӿڶ���-��β****************************/

#define Dummy_Byte   0xFF


/*�ȴ���ʱʱ��*/
#define SPIT_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define SPIT_LONG_TIMEOUT         ((uint32_t)(10 * SPIT_FLAG_TIMEOUT))

/*��Ϣ���*/
#define FLASH_DEBUG_ON            1

#define FLASH_INFO(fmt,arg...)           printf("<<-FLASH-INFO->> "fmt"\n",##arg)
#define FLASH_ERROR(fmt,arg...)          printf("<<-FLASH-ERROR->> "fmt"\n",##arg)
#define FLASH_DEBUG(fmt,arg...)          do{\
                                          if(FLASH_DEBUG_ON)\
                                          printf("<<-FLASH-DEBUG->> [%d]"fmt"\n",__LINE__, ##arg);\
                                          }while(0)


void SPI_SLAVE_Config(void);
static void DMA_NVIC_Config(void);
void SPI2_DMA_Config(void);
void SPI_SLAVE_Init(void);

static void SPI1_NVIC_Config(void);


u8 SPI_FLASH_ReadByte(void);
u8 SPI_FLASH_SendByte(u8 byte);
u16 SPI_FLASH_SendHalfWord(u16 HalfWord);


#endif /* __SPI2_H */

