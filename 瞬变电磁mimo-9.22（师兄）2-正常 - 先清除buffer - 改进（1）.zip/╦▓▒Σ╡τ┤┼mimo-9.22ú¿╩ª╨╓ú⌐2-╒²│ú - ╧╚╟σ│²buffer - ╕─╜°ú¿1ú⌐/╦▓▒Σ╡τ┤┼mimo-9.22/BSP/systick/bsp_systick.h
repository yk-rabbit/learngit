#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "stm32f4xx.h"




void systick_init(u8 sysclk);
void delay_ms(u16 nms);
void delay_us(u32 nus);
void delay_s(u16 ns);

void delay_osschedlock(void);
void delay_osschedunlock(void);
void delay_ostimedly(u32 ticks);
void delay_init(u8 SYSCLK);


#endif /* __SYSTICK_H */

