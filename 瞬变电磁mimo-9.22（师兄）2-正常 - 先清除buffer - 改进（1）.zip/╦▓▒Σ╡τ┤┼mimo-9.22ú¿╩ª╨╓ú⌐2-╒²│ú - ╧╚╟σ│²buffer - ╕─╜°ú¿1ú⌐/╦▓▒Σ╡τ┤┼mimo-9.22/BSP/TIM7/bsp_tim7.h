#ifndef __BSP_TIM7_H
#define	__BSP_TIM7_H

#include "stm32f4xx.h"

#define BASIC_TIM7           		TIM7
#define BASIC_TIM7_CLK       		RCC_APB1Periph_TIM7

#define BASIC_TIM7_IRQn				    TIM7_IRQn



void TIM7_Configuration(void);

#endif /* __BSP_TIM7_H */

