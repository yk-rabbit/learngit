#ifndef __SPI1_H
#define __SPI1_H

#include "stm32f4xx.h"
#include <stdio.h>


/*SPI�ӿڶ���-��ͷ****************************/
#define MASTER_SPI1                           SPI2
#define MASTER_SPI1_CLK                       RCC_APB1Periph_SPI2
#define MASTER_SPI1_CLK_INIT                  RCC_APB1PeriphClockCmd

#define MASTER_SPI1_SCK_PIN                   GPIO_Pin_13                  
#define MASTER_SPI1_SCK_GPIO_PORT             GPIOB                       
#define MASTER_SPI1_SCK_GPIO_CLK              RCC_AHB1Periph_GPIOB
#define MASTER_SPI1_SCK_PINSOURCE             GPIO_PinSource13
#define MASTER_SPI1_SCK_AF                    GPIO_AF_SPI2

#define MASTER_SPI1_MISO_PIN                  GPIO_Pin_14                
#define MASTER_SPI1_MISO_GPIO_PORT            GPIOB                   
#define MASTER_SPI1_MISO_GPIO_CLK             RCC_AHB1Periph_GPIOB
#define MASTER_SPI1_MISO_PINSOURCE            GPIO_PinSource14
#define MASTER_SPI1_MISO_AF                   GPIO_AF_SPI2

#define MASTER_SPI1_MOSI_PIN                  GPIO_Pin_15                
#define MASTER_SPI1_MOSI_GPIO_PORT            GPIOB                      
#define MASTER_SPI1_MOSI_GPIO_CLK             RCC_AHB1Periph_GPIOB
#define MASTER_SPI1_MOSI_PINSOURCE            GPIO_PinSource15
#define MASTER_SPI1_MOSI_AF                   GPIO_AF_SPI2

#define MASTER_SPI1_CS_PIN                    GPIO_Pin_12            
#define MASTER_SPI1_CS_GPIO_PORT              GPIOB                     
#define MASTER_SPI1_CS_GPIO_CLK               RCC_AHB1Periph_GPIOB

#define MASTER_SPI1_CS_LOW()             {MASTER_SPI1_CS_GPIO_PORT->BSRRH=MASTER_SPI1_CS_PIN;}
#define MASTER_SPI1_CS_HIGH()            {MASTER_SPI1_CS_GPIO_PORT->BSRRL=MASTER_SPI1_CS_PIN;}


/*SPI�ӿڶ���-��β****************************/


#define Dummy_Byte                0xFF
typedef unsigned char uint8;
typedef unsigned long uint32;
typedef unsigned long long uint64;

/*�ȴ���ʱʱ��*/
#define SPIT_FLAG_TIMEOUT         ((uint32_t)0x1000)
#define SPIT_LONG_TIMEOUT         ((uint32_t)(10 * SPIT_FLAG_TIMEOUT))

/*��Ϣ���*/
#define FLASH_DEBUG_ON         1

#define FLASH_INFO(fmt,arg...)           printf("<<-FLASH-INFO->> "fmt"\n",##arg)
#define FLASH_ERROR(fmt,arg...)          printf("<<-FLASH-ERROR->> "fmt"\n",##arg)
#define FLASH_DEBUG(fmt,arg...)          do{\
                                          if(FLASH_DEBUG_ON)\
                                          printf("<<-FLASH-DEBUG->> [%d]"fmt"\n",__LINE__, ##arg);\
                                          }while(0)

void SPI_MASTER1_Init(void);
u8 SPI_MASTER1_ReadByte(void);
u8 SPI_MASTER1_SendByte(u8 byte);
u16 SPI_MASTER1_SendHalfWord(u16 HalfWord);

										  
//u32 SPI_MASTER1_SendCmd(uint32 cmd);
void SPI_MASTER_SendCmd32(uint32 cmd);
void SPI_MASTER_SendCmd64(uint64_t cmd);
uint32 SPI_MASTER_SendandReadCmd(uint32_t cmd);
void SPI_MASTER2_SendCmd(uint32_t cmd);							 
										  
										  
										  
#endif /* __SPI1_H */

