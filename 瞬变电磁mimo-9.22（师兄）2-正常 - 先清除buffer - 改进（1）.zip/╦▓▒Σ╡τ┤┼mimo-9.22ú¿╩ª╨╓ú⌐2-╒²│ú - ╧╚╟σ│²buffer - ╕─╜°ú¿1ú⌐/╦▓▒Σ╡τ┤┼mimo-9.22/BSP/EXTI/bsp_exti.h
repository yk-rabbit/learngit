#ifndef __EXTI_H
#define	__EXTI_H

#include "stm32f4xx.h"

//���Ŷ���
/*******************************************************/
#define EXTI_INT_GPIO_PORT                GPIOA
#define EXTI_INT_GPIO_CLK                 RCC_AHB1Periph_GPIOA
#define EXTI_INT_GPIO_PIN                 GPIO_Pin_0
#define EXTI_INT_PORTSOURCE               EXTI_PortSourceGPIOA
#define EXTI_INT_PINSOURCE                EXTI_PinSource0
#define EXTI_INT_LINE                     EXTI_Line0
#define EXTI_INT_IRQ                      EXTI0_IRQn

#define EXTI_IRQHandler                   EXTI0_IRQHandler


/*******************************************************/


void EXTI_Config(void);

#endif /* __EXTI_H */
